<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="author" content="">
        <title>Syed Asad Ullah Hussaini | Sr. Graphic Designer | Hyderabad India</title>
        <!-- Google Font -->
        <link href='https://fonts.googleapis.com/css?family=Oswald:400,300,700,900' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>
        <!-- Styles -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/pe-icon-7-stroke/css/pe-icon-7.css">
        <link rel="stylesheet" href="assets/font-awesome-4.3.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/animate.min.css"> 
        <link rel="stylesheet" href="assets/css/animations.css"> 
        <link rel="stylesheet" href="assets/css/owl.carousel.css">             
        <link rel="stylesheet" href="assets/css/theme-red.css">
        <link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" href="assets/css/lightbox.min.css">
        <!--  Js -->
        <script src="assets/js/modernizr.custom.js"></script>
        <script src="assets/js/jquery-2.1.3.min.js"></script>
    </head>