<!-- PRELOADER -->
        <div class="preloader">
            <div class="spinner">
                <div class="dot1"></div>
                <div class="dot2"></div>
            </div>
        </div>    
        <!-- end: PRELOADER  --> 
		<nav>
            <!-- Logo -->
            <div class="logo-box">
                <a href="index.php" class="logo logo-img">
                    <img src="images/logo.png" class="img-responsive" alt="euforia">
                </a>
            </div>
            <!-- Menu button mobile -->
            <button type="button" aria-label="Toggle Navigation" class="menu-button-mobile lines-button x2">
                <span class="lines"></span>
            </button>
            <!-- Menu -->
            <div class="menu-box my-scrollbar">
                <div id="dl-menu" class="dl-menuwrapper">
                    <ul class="dl-menu dl-menuopen">
                        <li><a class="page-link" href="index.php#home" data-hover="home">home</a></li>  
                        <li><a class="page-link" href="index.php#about" data-hover="about me">about me</a></li> 
                        <li><a class="page-link" href="index.php#services" data-hover="services">services</a></li>
                        <li><a class="page-link" href="index.php#portfolio" data-hover="portfolio">portfolio</a></li>
                        <li><a class="" href="images/resume.pdf" data-hover="My Resume" target="_blank" >My Resume</a></li>
                        <li><a class="page-link" href="index.php#contact" data-hover="contact">contact</a></li>
                        <!-- submenu / extra -->
                        
                        <!-- END: submenu / extra -->
                    </ul>  
                </div>  
            </div>
            <footer class="footer">
                <ul class="social-icons social-v3">
                    <li><a href="#" target="_blank" class="fa fa-facebook"><i class="fa fa-facebook color-default"></i></a></li>
                    <li><a href="https://plus.google.com/+AsadHussaini" target="_blank" class="fa fa-google-plus"><i class="fa fa-google-plus color-default"></i></a></li>
                    <li><a href="https://www.linkedin.com/in/asadgraphicdesigner/" target="_blank" class="fa fa-linkedin"><i class="fa fa-linkedin color-default"></i></a></li> 
                    <li><a href="https://www.behance.net/ilovedesign" target="_blank" class="fa fa-behance"><i class="fa fa-behance color-default"></i></a></li>
                </ul>   
                <div class="copyright">&copy; 2018 <a href="index.php">Syed Asad</a>.</div>
            </footer>       
        </nav>