<?php include("includes/css.php");?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139199804-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-139199804-1');

</script>

<body>
    <?php include("includes/nav.php");?>
    <!-- PAGE-WRAPPER -->
    <div class="page-wrapper">
        <div class="page-ajax-preloader">
            <i class="fa fa-refresh fa-spin"></i>
            <span>Loading...</span>
        </div>
        <!-- HOME Section -->
        <section id="home" class="page-activ">
            <div class="content table home-bg">
                <div class="table-middle">
                    <div class="intro-text">
                        <h1>
                            <strong>I'm <span class="color-default">&nbsp;Syed Asad&nbsp;</span></strong>
                        </h1>
                        <div class="owl-carousel rotate-text">
                            <div class="item">
                                <h3> <strong> Sr. Graphic Designer</strong></h3>
                            </div>
                            <div class="item">
                                <h3><strong>Pharma Packaging & Labeling</strong></h3>
                            </div>
                        </div>
                        <!-- end: OWL-CAROUSERL  -->
                    </div>
                    <!-- .intro-text -->
                </div>
                <!-- .table-middle -->
            </div>
            <!-- .content -->
        </section>
        <!-- end: HOME Section -->
        <!-- ABOUT Section -->
        <section id="about">
            <div class="content">
                <div class="container about">
                    <header>
                        <h3>About Me<small>About</small></h3>
                        <h5>I'm a Desinger and an artist</h5>
                    </header>
                    <!--  image & text -->
                    <div class="row">
                        <div class="col-md-5 no-padding">
                            <img src="images/asad.jpeg" class="img-responsive center-block" alt="Syed Asad Ullah Hussaini">
                        </div>
                        <div class="col-md-7 col-box bg-gray-light">
                            <div class="page-header">
                                <h4>Hello There, I'm Syed Asad.</h4>
                            </div>
                            <p>My name is Syed Asad, I am a Graphic Designer specialist in Artworker for Pharmaceutical Packaging and Labelling. Please see some brief information about my career.</p>
                            <h2 class="text-right color-white"><strong>MY JOURNEY</strong></h2>
                            <p>I have start my career in July 2007 as a Junior Web and Graphic designer at Abrif software solution, my responsibility to support web and Graphic both team to Design Website layout, Website HTML Conversion (slicing), Designed logo and print products including brochures, business cards, thank you cards, banners, customized letter heads, faxes, stationery etc.<br> From May 2011 I have started the Freelance work at home, in freelancing I have designing the broachers, websites, poster, advert & exhibition graphic and provide the print ready file to client for printing, Creating and maintaining graphics for company websites.<br>
                                In 2014 I got the offer from Al raja Printing press Saudi Arabia as a prepress designer, in Al Raja printing press my responsibility is to preparing file for printing (Pre-press), ensure that the artwork should be proper format, appearance. And Determine page layout, color format, fonts, graphics quality, text and images is set before the full print run.<br> Check the artwork should be appropriate bleeds and gripper, adding crop marks and color bars as necessary; send press-ready documents and final layout at both rip and press stations; and provide mock-up to pressman and coordinate printing schedules.
                            </p>

                        </div>
                        <div class="col-md-12 col-box bg-gray-light">
                            <p>

                                Create Artwork for prepress and production design for large & small format printing (color matching, size reformatting, adding die cuts, etc), Quality check on created artworks before sending to the printing press for mass printing.<br>
                                Strong Systematic knowledge of color-separation, bleeding and other print-related technical troubleshooting areas.<br>
                                In 2016 I have back to India and join in Freyr Solutions as a Sr. Graphic Designer,
                                In Freyr Solutions my responsibility is to manage the changes required in product packaging basis customer brief, Adapting the customer artwork to the new packaging by converting the source language into different languages (right to left languages like Hebrew, Arabic, Urdu etc).<br>
                                Artwork must be 100% accurate.<br>
                                Artwork for packaging components must be completed and be available to meet submission and production schedules.<br>
                                Create artwork for printed packaging components.<br>
                                Proofread text for labeling of pharmaceutical products as required regulatory.<br>
                                Ensure that labeling artwork and proofs meet all medical, legal and regulatory requirements.<br>
                                Ensure the accuracy of commercial packaging components.<br>
                                Ensure regulatory compliance, accuracy, timely completion and version control of all new and revised text on labeling components.<br>
                                Perform continuous coordination, monitoring and expediting of labelling changes to meet established deadlines submission and production (including sup-port of product launch).<br>
                                Ensure all typesetting of packaging components (including the text, graphics, chemical structures, bar codes etc.,) are as per medical guidelines and standard.<br>
                                Strong Systematic knowledge of color-separation, bleeding and other print-related technical troubleshooting areas.
                            </p>
                            <h2 class="text-right color-white"><strong>MY JOURNEY</strong></h2>
                        </div>
                    </div>
                    <!-- .row -->
                    <!--  end: images & text -->
                    <div class="space100 hidden-sm hidden-xs"></div>
                    <!-- testimonial & skills -->
                    <div class="row">
                        <div class="col-md-6 col-box bg-white">
                            <div class="page-header">
                                <h4>About Me</h4>
                            </div>
                            <div class="about_asad">
                                <ul>
                                    <li><span><i class="fa fa-user"></i> Name</span><label>Syed Asadullah Hussaini</label></li>
                                    <div class="clearfix"></div>
                                    <li><span><i class="fa fa-calendar"></i> Date of birth</span><label>09 Jun 1987</label></li>
                                    <div class="clearfix"></div>
                                    <li><span><i class="fa fa-phone"></i> Phone</span><label>+91 970 369 7344</label></li>
                                    <div class="clearfix"></div>
                                    <li><span><i class="fa fa-paper-plane"></i> Email</span><label>syedasadhussaini@gmail.com</label></li>
                                    <div class="clearfix"></div>
                                    <li><span><i class="fa fa-globe"></i> Web</span><label>syedasad.com</label></li>
                                    <div class="clearfix"></div>
                                    <li><span><i class="fa fa-map-marker"></i> Address</span><label>hyderabad 500008 India</label></li>
                                </ul>
                            </div>
                            <h2 class="text-right color-gray-light"><strong>ABOUT ME</strong></h2>
                        </div>
                        <!-- end: testimonial -->
                        <!-- skills -->
                        <div class="skills col-md-6 col-box bg-white">
                            <div class="page-header">
                                <h4>My Skills</h4>
                            </div>
                            <ul class="list-unstyled">
                                <li>
                                    <div class="progress" style="width: 85%;">
                                        <div class="progress-percent">85%</div>
                                    </div>
                                    <span>Adobe Photoshop</span>
                                </li>
                                <li>
                                    <div class="progress" style="width: 85%;">
                                        <div class="progress-percent">85%</div>
                                    </div>
                                    <span>Adobe Illustrator</span>
                                </li>
                                <li>
                                    <div class="progress" style="width: 80%;">
                                        <div class="progress-percent">80%</div>
                                    </div>
                                    <span>Adobe Indesign</span>
                                </li>
                                <li>
                                    <div class="progress" style="width: 70%;">
                                        <div class="progress-percent">70%</div>
                                    </div>
                                    <span>Adobe Flash</span>
                                </li>
                                <li>
                                    <div class="progress" style="width: 70%;">
                                        <div class="progress-percent">70%</div>
                                    </div>
                                    <span>Corel Draw</span>
                                </li>
                            </ul>
                            <h2 class="text-right color-gray-light"><strong>MY SKILLS</strong></h2>
                        </div>
                        <!-- end: skills -->
                    </div>
                    <!-- .row -->
                    <!-- end: testimonial & skills -->
                    <div class="space100 hidden-sm hidden-xs"></div>
                    <!-- achivements -->
                    <!-- end: achivements -->
                    <div class="space80 hidden-sm hidden-xs"></div>
                    <div class="space20"></div>
                    <!-- timeline -->
                    <div class="timeline">
                        <div class="page-header">
                            <h4>Professional Experience</h4>
                        </div>
                        <div class="timeline-item">
                            <div class="lt-date-icon">
                                <div class="tl-date">
                                    <span>August &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Present</span>
                                    <span>2016 - Present</span>
                                </div>
                                <span class="tl-icon fa-stack">
                                    <i class="fa fa-circle fa-stack-2x color-gray-light"></i>
                                    <i class="fa fa-briefcase fa-stack-1x color-default"></i>
                                </span>
                            </div>
                            <!-- .lt-date-ico -->
                            <div class="tl-box bg-white anim-shadow">
                                <h6 class="title">Graphic Designer - Freyr Solutions</h6>
                                <p>
                                    <i class="fa fa-sign-out"></i>Managing the changes required in product packaging basis customer brief, Adapting the customer artwork to the new packaging by converting the source language into different languages (right to left languages like Hebrew, Arabic, Urdu etc). <br>
                                    <i class="fa fa-sign-out"></i> Artwork must be 100% accurate.<br>
                                    <i class="fa fa-sign-out"></i> Artwork for packaging components must be completed and be available to meet submission and production schedules. <br>
                                    <i class="fa fa-sign-out"></i> Create artwork for printed packaging components.<br>
                                    <i class="fa fa-sign-out"></i> Proofread text for labeling of pharmaceutical products as required regulatory.<br>
                                    <i class="fa fa-sign-out"></i> Ensure that labeling artwork and proofs meet all medical, legal and regulatory requirements.
                                    <br>
                                    <i class="fa fa-sign-out"></i> Ensure the accuracy of commercial packaging components.<br>
                                    <i class="fa fa-sign-out"></i> Ensure regulatory compliance, accuracy, timely completion and version control of all new and revised text on labeling components.<br>
                                    <i class="fa fa-sign-out"></i> Perform continuous coordination, monitoring and expediting of labeling changes to meet established deadlines submission and production (including sup-port of product launch).
                                    <br>
                                    <i class="fa fa-sign-out"></i> Ensure all typesetting of packaging components (including the text, graphics, chemical structures, bar codes etc.,) are as per medical guidelines and standard.<br>
                                    <i class="fa fa-sign-out"></i> Strong Systematic knowledge of color-separation, bleeding and other print-related technical troubleshooting areas.
                                </p>
                            </div>
                            <!-- .tl-box -->
                        </div>
                        <!-- .timeline-item -->
                        <div class="timeline-item">
                            <div class="lt-date-icon">
                                <div class="tl-date">
                                    <span>May &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; June</span>
                                    <span>2014 - 2016</span>
                                </div>
                                <span class="tl-icon fa-stack">
                                    <i class="fa fa-circle fa-stack-2x color-gray-light"></i>
                                    <i class="fa fa-briefcase fa-stack-1x color-default"></i>
                                </span>
                            </div>
                            <!-- .lt-date-ico -->
                            <div class="tl-box bg-white anim-shadow">
                                <h6 class="title">Graphic Designer - AL RAJA PRINTING PRESS SALMAN GROUP KSA</h6>
                                <p>Preparation of file for printing (Pre-Press) Ensure that the proper format, appearance, and layout of text and images is set before the full print run for newspapers, magazines, brochures, catalogs, packaging materials or labels is completed. Check for appropriate color format, fonts, and graphics for quality, Determine page layout, bleeds and gripper, adding crop marks and color bars as necessary; send press-ready documents and final layout at both rip and press stations; and provide mock-up to pressman and coordinate printing schedules. Prepress and production design for large & small format printing (color matching, size reformatting, adding die cuts, etc), Quality check on created artworks before sending to the printing press for mass printing. Strong Systematic knowledge of color-separation, bleeding and other print-related technical troubleshooting areas.</p>
                            </div>
                            <!-- .tl-box -->
                        </div>
                        <!-- .timeline-item -->
                        <div class="timeline-item">
                            <div class="lt-date-icon">
                                <div class="tl-date">
                                    <span>May &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; May</span>
                                    <span>2011 - 2014</span>
                                </div>
                                <span class="tl-icon fa-stack">
                                    <i class="fa fa-circle fa-stack-2x color-gray-light"></i>
                                    <i class="fa fa-briefcase fa-stack-1x color-default"></i>
                                </span>
                            </div>
                            <!-- .lt-date-ico -->
                            <div class="tl-box bg-white anim-shadow">
                                <h6 class="title">Graphic Designer - Freelance</h6>
                                <p>
                                    <i class="fa fa-sign-out"></i>Preparing and successfully pitching designs both internally and externally to clients. <br>
                                    <i class="fa fa-sign-out"></i> Designing prospectuses, brochures, websites, posters, adverts & exhibition graphics.<br>
                                    <i class="fa fa-sign-out"></i> Liaising with stakeholders and marketing teams on project requirements.<br>
                                    <i class="fa fa-sign-out"></i> Giving support and advice to colleagues on a wide range of Graphic Design processes.<br>
                                    <i class="fa fa-sign-out"></i> Involved in the creation and development of new designs and visual concepts, across a broad spectrum of styles.<br>
                                    <i class="fa fa-sign-out"></i> Working across a wide variety of digital and print projects.<br>
                                    <i class="fa fa-sign-out"></i> Designing graphics to a client’s precise requirements and brief.<br>
                                    <i class="fa fa-sign-out"></i> Creating and maintaining graphics for company websites.<br>
                                    <i class="fa fa-sign-out"></i> Preparing files to print and then sending them to the printers<br>
                                </p>
                            </div>
                            <!-- .tl-box -->
                        </div>
                        <!-- .timeline-item -->
                        <div class="timeline-item">
                            <div class="lt-date-icon">
                                <div class="tl-date">
                                    <span>May &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; May</span>
                                    <span>2007 - 2011</span>
                                </div>
                                <span class="tl-icon fa-stack">
                                    <i class="fa fa-circle fa-stack-2x color-gray-light"></i>
                                    <i class="fa fa-briefcase fa-stack-1x color-default"></i>
                                </span>
                            </div>
                            <!-- .lt-date-ico -->
                            <div class="tl-box bg-white anim-shadow">
                                <h6 class="title">Graphic Designer - ABRIF Software solution</h6>
                                <p>
                                    <i class="fa fa-sign-out"></i>Designed logo and print products including brochures, business cards, thank you cards, banners, customized letter heads, faxes, stationery etc.<br>
                                    <i class="fa fa-sign-out"></i>Create a Magazine in Urdu and English language www.hiemirates.com<br>
                                    <i class="fa fa-sign-out"></i>Design Website layout<br>
                                    <i class="fa fa-sign-out"></i>Website HTML Conversion (slicing)<br>
                                    <i class="fa fa-sign-out"></i>Build CSS Based websites<br>
                                    <i class="fa fa-sign-out"></i>Comprehensive technical knowledge of HTML coding.<br>
                                    <i class="fa fa-sign-out"></i>Excellent knowledge in Flash<br>
                                </p>
                            </div>
                            <!-- .tl-box -->
                        </div>
                        <!-- .timeline-item -->
                    </div>
                    <!-- end: timeline -->
                    <div class="space50 hidden-sm hidden-xs"></div>
                </div>
                <!-- .container-fluid -->
            </div>
            <!-- .content -->
        </section>
        <!-- end: ABOUT Section -->
        <!-- SERVICES Section -->
        <section id="services">
            <div class="content">
                <div class="container">
                    <header>
                        <h3>My Services<small>Services</small></h3>
                        <h5>What i can do</h5>
                    </header>
                </div>
                <!-- .container  -->
                <div class="space60 hidden-xs"></div>
                <h1 class="text-center">Coming Soon...!</h1>
            </div>
            <!-- .content -->
        </section>
        <!-- end: SERVICES Section -->
        <!-- PORTFOLIO Section -->
        <section id="portfolio" style="background:#fff;border-left:1px solid #0079c1">
            <div class="content">
                <div class="container">
                    <header>
                        <h3>My Portfolio<small>Portfolio</small></h3>
                        <h5>My best works</h5>
                    </header>
                    <div id="portfolio-filter">
                        <!-- portfolio-colum -->
                        <div class="portfolio-colum portfolio-masonry masonry-grid-3 portfolio-padding15 portfolio-hover">
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/1.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/1.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/2.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/2.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/3.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/3.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/4.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/4.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/5.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/5.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/6.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/6.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/7.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/7.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/8.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/8.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "pharma-packaging"]'>
                                <a class="example-image-link" href="images/pharma-packaging/9.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/pharma-packaging/9.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/1.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/1.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/2.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/2.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/3.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/3.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/4.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/4.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/5.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/5.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/6.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/6.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/7.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/7.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/8.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/8.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/9.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/9.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/10.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/10.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/11.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/11.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "consumer-health"]'>
                                <a class="example-image-link" href="images/consumer-health/12.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/consumer-health/12.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "fmcg"]'>
                                <a class="example-image-link" href="images/fmcg/1.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/fmcg/1.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "fmcg"]'>
                                <a class="example-image-link" href="images/fmcg/2.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/fmcg/2.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "fmcg"]'>
                                <a class="example-image-link" href="images/fmcg/3.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/fmcg/3.jpg" alt="" /></a>
                            </figure>
                            <div class="clearfix"></div>
                            <figure class="item" data-groups='["all", "fmcg"]'>
                                <a class="example-image-link" href="images/fmcg/4.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/fmcg/4.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "menu-card"]'>
                                <a class="example-image-link" href="images/menu-card/1.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/menu-card/1.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "menu-card"]'>
                                <a class="example-image-link" href="images/menu-card/2.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/menu-card/2.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "flayer"]'>
                                <a class="example-image-link" href="images/flayer/1.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/flayer/1.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "flayer"]'>
                                <a class="example-image-link" href="images/flayer/2.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/flayer/2.jpg" alt="" /></a>
                            </figure>
                            <figure class="item" data-groups='["all", "flayer"]'>
                                <a class="example-image-link" href="images/flayer/3.jpg" data-lightbox="example-set" data-title=""><img class="example-image" src="images/flayer/3.jpg" alt="" /></a>
                            </figure>
                        </div>
                    </div>
                    <div class="space20"></div>
                </div>
                <!-- .container -->
            </div>
            <!-- .content -->
        </section>
        <!-- end: PORTFOLIO Section -->
        <!-- BLOG Section -->
        <section id="blog">
            <div class="content">
                <div class="container">
                    <header>
                        <h3>My Blog<small>Blog</small></h3>
                        <h5>My Diary</h5>
                    </header>
                    <div class="blog-masonry">
                        <div class="item-sizer"></div>
                        <div class="item">
                            <div class="blog-box anim-shadow">
                                <div class="blog-box-img">
                                    <img src="assets/img/blog/1.jpg" class="img-responsive" alt="">
                                </div>
                                <div class="blog-box-caption">
                                    <div class="category">
                                        <a href="#" rel="category tag">bootstrap</a>
                                    </div>
                                    <h5 class="title">Bootstrap is The Most Popular Framework</h5>
                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                    </p>
                                    <a class="ajax-loader read-more" href="blog-post1.html">
                                        read more<i class="fa fa-fw fa-long-arrow-right"></i>
                                    </a>
                                </div>
                                <!-- .blog-box-caption -->
                                <div class="blog-box-footer">
                                    <span class="autor">By John Doe</span>
                                    <span class="separator">|</span>
                                    <span class="date"><i class="fa fa-fw fa-clock-o"></i>26 May, 2014</span>
                                    <span class="like pull-right"><i class="fa fa-fw fa-thumbs-o-up"></i>0</span>
                                </div>
                                <!-- .blog-box-footer -->
                            </div>
                            <!-- .blog-box -->
                        </div>
                        <!-- .item -->
                        <div class="item">
                            <div class="blog-box">
                                <div class="blog-box-img">
                                    <img src="assets/img/blog/2.jpg" class="img-responsive" alt="">
                                </div>
                                <div class="blog-box-caption">
                                    <div class="category">
                                        <a href="#" rel="category tag">css3</a>
                                        <a href="#" rel="category tag">html5</a>
                                        <a href="#" rel="category tag">javascript</a>
                                    </div>
                                    <h5 class="title">The Only Responsive Templates</h5>
                                    <p>
                                        <i>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</i>
                                        <br> When an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                    </p>
                                    <a class="ajax-loader read-more" href="blog-post1.html">
                                        read more<i class="fa fa-fw fa-long-arrow-right"></i>
                                    </a>
                                </div>
                                <!-- .blog-box-caption -->
                                <div class="blog-box-footer">
                                    <span class="autor">By John Doe</span>
                                    <span class="separator">|</span>
                                    <span class="date"><i class="fa fa-fw fa-clock-o"></i>18 May, 2014</span>
                                    <span class="like pull-right"><i class="fa fa-fw fa-thumbs-o-up"></i>99</span>
                                </div>
                                <!-- .blog-box-footer -->
                            </div>
                            <!-- .blog-box -->
                        </div>
                        <!-- .item -->
                        <div class="item">
                            <div class="blog-box anim-shadow">
                                <div class="blog-box-img">
                                    <img src="assets/img/blog/3.jpg" class="img-responsive" alt="">
                                </div>
                                <div class="blog-box-caption">
                                    <h5 class="title">Clean and Fresh Fully Responsive Template</h5>
                                    <p>
                                        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                    </p>
                                    <a class="ajax-loader read-more" href="blog-post1.html">
                                        read more<i class="fa fa-fw fa-long-arrow-right"></i>
                                    </a>
                                </div>
                                <!-- .blog-box-caption -->
                                <div class="blog-box-footer">
                                    <span class="autor">By John Doe</span>
                                    <span class="separator">|</span>
                                    <span class="date"><i class="fa fa-fw fa-clock-o"></i>18 May, 2014</span>
                                    <span class="like pull-right"><i class="fa fa-fw fa-thumbs-o-up"></i>123</span>
                                </div>
                                <!-- .blog-box-footer -->
                            </div>
                            <!-- .blog-box -->
                        </div>
                        <!-- .item -->
                        <div class="item">
                            <div class="blog-box anim-shadow">
                                <div class="blog-box-img">
                                    <img src="assets/img/blog/4.jpg" class="img-responsive" alt="">
                                </div>
                                <div class="blog-box-caption">
                                    <h5 class="title">This is an video post</h5>
                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                    </p>
                                    <a class="ajax-loader read-more" href="blog-post1.html">
                                        read more<i class="fa fa-fw fa-long-arrow-right"></i>
                                    </a>
                                </div>
                                <!-- .blog-box-caption -->
                                <div class="blog-box-footer">
                                    <span class="autor">By John Doe</span>
                                    <span class="separator">|</span>
                                    <span class="date"><i class="fa fa-fw fa-clock-o"></i>18 May, 2014</span>
                                    <span class="like pull-right"><i class="fa fa-fw fa-thumbs-o-up"></i>99</span>
                                </div>
                                <!-- .blog-box-footer -->
                            </div>
                            <!-- .blog-box -->
                        </div>
                        <!-- .item -->
                        <div class="item">
                            <div class="blog-box anim-shadow">
                                <div class="blog-box-img">
                                    <img src="assets/img/blog/1.jpg" class="img-responsive" alt="">
                                </div>
                                <div class="blog-box-caption">
                                    <h5 class="title">The Only Responsive Templates</h5>
                                    <p>
                                        <em>Lorem ipsum dolor sit amet, sociis natoque perse penatibus et magnistra dis parturient.</em>
                                        <br /> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                    </p>
                                    <a class="ajax-loader read-more" href="blog-post1.html">
                                        read more<i class="fa fa-fw fa-long-arrow-right"></i>
                                    </a>
                                </div>
                                <!-- .blog-box-caption -->
                                <div class="blog-box-footer">
                                    <span class="autor">By John Doe</span>
                                    <span class="separator">|</span>
                                    <span class="date"><i class="fa fa-fw fa-clock-o"></i>18 May, 2014</span>
                                    <span class="like pull-right"><i class="fa fa-fw fa-thumbs-o-up"></i>99</span>
                                </div>
                                <!-- .blog-box-footer -->
                            </div>
                            <!-- .blog-box -->
                        </div>
                        <!-- .item -->
                        <div class="item">
                            <div class="blog-box anim-shadow">
                                <div class="blog-box-img">
                                    <img src="assets/img/blog/2.jpg" class="img-responsive" alt="">
                                </div>
                                <div class="blog-box-caption">
                                    <h5 class="title">The Only Responsive Templates</h5>
                                    <p>
                                        Lorem ipsum dolor sit amet, sociis natoque perse penatibus et magnistra dis parturient.
                                        <br> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                    </p>
                                    <a class="ajax-loader read-more" href="blog-post1.html">
                                        read more<i class="fa fa-fw fa-long-arrow-right"></i>
                                    </a>
                                </div>
                                <!-- .blog-box-caption -->
                                <div class="blog-box-footer">
                                    <span class="autor">By John Doe</span>
                                    <span class="separator">|</span>
                                    <span class="date"><i class="fa fa-fw fa-clock-o"></i>18 May, 2014</span>
                                    <span class="like pull-right"><i class="fa fa-fw fa-thumbs-o-up"></i>99</span>
                                </div>
                                <!-- .blog-box-footer -->
                            </div>
                            <!-- .blog-box -->
                        </div>
                        <!-- .item -->
                    </div>
                    <!-- .blog-masonry -->
                    <div class="blog-loadmore">
                        <a class="btn btn-default" href="#">Load More</a>
                    </div>
                </div>
                <!-- .container -->
            </div>
            <!-- .content -->
        </section>
        <!-- end: BLOG Section -->
        <!-- CONTACT Section -->
        <section id="contact">
            <div class="content">
                <div class="container">
                    <header>
                        <h3>Contact Me<small>Contact</small></h3>
                        <h5>get in touch</h5>
                    </header>
                    <div class="row">
                        <!-- contact-details -->
                        <div class="col-sm-6 contact-details">
                            <div class="space20"></div>
                            <h4 class="text-uppercase">Get In Touch</h4>
                            <div class="fatures">
                                <div class="ft-item">
                                    <div class="ft-icon pull-left">
                                        <i class="pe-7s-home pe-2x color-default"></i>
                                    </div>
                                    <div class="ft-text">
                                        <h6 class="weight300">Adress</h6>
                                        <p>Nizam Colony, Tolichowki, Hyderabad.</p>
                                    </div>
                                </div>
                                <!-- .ft-item  -->
                                <div class="ft-item">
                                    <div class="ft-icon pull-left">
                                        <i class="pe-7s-call pe-2x color-default"></i>
                                    </div>
                                    <div class="ft-text">
                                        <h6>Phone</h6>
                                        <p>+91 970 369 7344</p>
                                    </div>
                                </div>
                                <!-- .ft-item  -->
                                <div class="ft-item">
                                    <div class="ft-icon pull-left">
                                        <i class="pe-7s-mail pe-2x color-default"></i>
                                    </div>
                                    <div class="ft-text">
                                        <h6>Mail</h6>
                                        <p>syedasadhussaini@gmail.com</p>
                                    </div>
                                </div>
                                <!-- .ft-item  -->
                            </div>
                            <!-- .fatures -->
                            <div class="space30"></div>
                            <!-- SOCIAL-ICONS -->
                            <ul class="social-icons social-v2 social-2x">
                                <li><a href="#" target="_blank" class="fa fa-facebook"><i class="fa fa-facebook color-default"></i></a></li>
                                <li><a href="https://plus.google.com/+AsadHussaini" target="_blank" class="fa fa-google-plus"><i class="fa fa-google-plus color-default"></i></a></li>
                                <li><a href="https://sa.linkedin.com/in/webandgraphicdesinger" target="_blank" class="fa fa-linkedin"><i class="fa fa-linkedin color-default"></i></a></li>
                                <li><a href="https://www.behance.net/ilovedesign" target="_blank" class="fa fa-behance"><i class="fa fa-behance color-default"></i></a></li>
                            </ul>
                            <!-- end: SOCIAL-ICONS -->
                            <div class="space30"></div>
                        </div>
                        <!-- end: .contact-details -->
                        <!-- contact-form -->
                        <div class="col-sm-6 col-box bg-gray-light contact-form">
                            <h4 class="text-uppercase">Contact Form</h4>
                            <?php
											//if "email" variable is filled out, send email
											  if (isset($_REQUEST['email']))  {
											  //Email information
											  $admin_email = "khaleelhusaini@gmail.com";
											  $email = $_REQUEST['email'];
											  $name = $_REQUEST['name'];
											  $contact_number = $_REQUEST['contact_number'];
											  $comment = $_REQUEST['comment'];
											  //send email
											  mail($admin_email, "$subject", $comment, "From:" . $email);
											  //Email response
											  echo "Thank you for contacting us!";
											  }
											  //if "email" variable is not filled out, display the form
											  else  {
											?>
                            <form class="form-style" action="" method="post">
                                <div class="form-group">
                                    <input type="text" class="text-field form-control" placeholder="Full Name" name="name" />
                                    <i class="form-icon fa fa-user"></i>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="text-field form-control" placeholder="Email Address" name="email" />
                                    <i class="form-icon fa fa-envelope"></i>
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="text-field form-control" placeholder="Contact Number" name="contact_number" />
                                    <i class="form-icon fa fa-phone"></i>
                                </div>
                                <div class="form-group">
                                    <textarea placeholder="Message..." class="form-control" name="comment"></textarea>
                                    <i class="form-icon fa fa-comment"></i>
                                </div>
                                <div class="form-group submit">
                                    <span class="form-loader"><i class="fa fa-spinner fa-spin"></i></span>
                                    <button type="submit" name="submit" class="btn btn-default">Send message</button>
                                </div>
                                <div class="alert-validate-form"></div>
                            </form>
                            <?php
  }
?>
                        </div>
                        <!-- end: .contact-form -->
                    </div>
                    <!-- .row -->
                </div>
                <!-- .container -->
            </div>
            <!-- .content -->
        </section>
        <!-- end: CONTACT Section -->
    </div>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/masonry.pkgd.min.js"></script>
    <script src="assets/js/jquery.backstretch.min.js"></script>
    <script src="assets/js/jquery.stellar.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/jquery.shuffle.min.js"></script>
    <script src="assets/js/jquery.hoverdir.js"></script>
    <script src="assets/js/jquery.lazy.min.js"></script>
    <script src="assets/js/functions.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/lightbox-plus-jquery.min.js"></script>
    <script src="assets/style-switcher/style-switcher.js"></script>
   
</body>

</html>
